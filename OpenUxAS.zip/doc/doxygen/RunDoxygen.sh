#!/bin/bash

doxygen Doxyfile

cp files/* html/

