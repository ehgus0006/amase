
dot  -Tpng -o "UxAS_DiscreteEventSimulaton.png" -Kdot UxAS_DiscreteEventSimulaton.gv
# dot  -Tpng -o "CCA_VisibilityGraphAddVehiclesObjectives.png" -Kdot CCA_VisibilityGraphAddVehiclesObjectives.txt



# dot  -Tpng -o "CCA_CAllocationRouting_errRunAllocation.png" -Kdot CCA_CAllocationRouting_errRunAllocation.txt
# dot  -Tpng -o "CCA_CMASIMain.png" -Kdot CCA_CMASIMain.txt
# dot  -Tpng -o "CCA_CMASI_ProcessMessages.png" -Kdot CCA_CMASI_ProcessMessages.txt
# dot  -Tpng -o "CCA_CMASI_ProcessPlanRequest.png" -Kdot CCA_CMASI_ProcessPlanRequest.txt
# dot  -Tpng -o "CCA_InformationFlow.png" -Kdot CCA_InformationFlow.txt
# dot  -Tpng -o "CCA_MessageFlow.png" -Kdot CCA_MessageFlow.txt
# dot  -Tpng -o "CCA_MissionSolverFunctionalFlow.png" -Kdot CCA_MissionSolverFunctionalFlow.txt
# dot  -Tpng -o "CCA_ObjectivesFunctionalFlow.png" -Kdot CCA_ObjectivesFunctionalFlow.txt
# dot  -Tpng -o "CCA_PathPlanningFunctionalFlow.png" -Kdot CCA_PathPlanningFunctionalFlow.txt
# dot  -Tpng -o "CCA_ProcessAlgebraFunctionalFlow.png" -Kdot CCA_ProcessAlgebraFunctionalFlow.txt
# dot  -Tpng -o "CCA_SearchPathFunctionalFlow.png" -Kdot CCA_SearchPathFunctionalFlow.txt
# dot  -Tpng -o "CCA_VisibilityGraphFunctionalFlow.png" -Kdot CCA_VisibilityGraphFunctionalFlow.txt
# dot  -Tpng -o "CCA_SensorCoordinatedAssignmentFunctionalFlow.png" -Kdot CCA_SensorCoordinatedAssignmentFunctionalFlow.txt







# dot  -Tps -o "CCA_CAllocationRouting_errRunAllocation.ps" -Kdot CCA_CAllocationRouting_errRunAllocation.txt
# ps2pdf CCA_CAllocationRouting_errRunAllocation.ps CCA_CAllocationRouting_errRunAllocation.pdf
# dot  -Tps -o "CCA_CMASIMain.ps" -Kdot CCA_CMASIMain.txt
# dot  -Tps -o "CCA_CMASI_ProcessMessages.ps" -Kdot CCA_CMASI_ProcessMessages.txt
# dot  -Tps -o "CCA_CMASI_ProcessPlanRequest.ps" -Kdot CCA_CMASI_ProcessPlanRequest.txt
# dot  -Tps -o "CCA_InformationFlow.ps" -Kdot CCA_InformationFlow.txt
# dot  -Tps -o "CCA_MessageFlow.ps" -Kdot CCA_MessageFlow.txt
# dot  -Tps -o "CCA_MissionSolverFunctionalFlow.ps" -Kdot CCA_MissionSolverFunctionalFlow.txt
# dot  -Tps -o "CCA_ObjectivesFunctionalFlow.ps" -Kdot CCA_ObjectivesFunctionalFlow.txt
# dot  -Tps -o "CCA_PathPlanningFunctionalFlow.ps" -Kdot CCA_PathPlanningFunctionalFlow.txt
# dot  -Tps -o "CCA_ProcessAlgebraFunctionalFlow.ps" -Kdot CCA_ProcessAlgebraFunctionalFlow.txt
# dot  -Tps -o "CCA_SearchPathFunctionalFlow.ps" -Kdot CCA_SearchPathFunctionalFlow.txt
# dot  -Tps -o "CCA_VisibilityGraphFunctionalFlow.ps" -Kdot CCA_VisibilityGraphFunctionalFlow.txt
# dot  -Tps -o "CCA_SensorCoordinatedAssignmentFunctionalFlow.ps" -Kdot CCA_SensorCoordinatedAssignmentFunctionalFlow.txt
