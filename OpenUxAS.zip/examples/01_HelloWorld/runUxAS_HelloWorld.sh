#! /bin/bash

BIN="../../build/uxas"
$BIN -cfgPath cfg_HelloWorld.xml

